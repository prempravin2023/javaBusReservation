package Busdatabasefullproject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validation {
	Scanner i=new Scanner(System.in);
	Scanner s=new Scanner(System.in);
	String Aid;
	String name;
    String email;
	String phonenum;
	String password;
	String fromlocation;
	String Tolocation;
	Date locdate;
	Date fromdate;
	Date usefromdate;
	int bus_no;
public  void Register() 
	
	{
		name();
		email();
		phnum();
		System.out.println("Set your password : ");
		password=s.next();
		
	}
public boolean id() {
		System.out.println("Enter your id : ");
	     String cAid=s.nextLine();
		
		String regex="^[0-9]{3,6}$";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(cAid);
		if(m.matches()) {
			Aid=cAid;
			return true;
		}
		else if(cAid==null)
		{
			System.out.println("id is empty please give a one id ");
			return id();
		}
		else
		{
			System.out.println("sry id should minimum Three numbers or Id should only numbers...... ");
			return id();
		}
}

public boolean name() {
		System.out.println("Enter your name : ");
		String cname=s.nextLine();
		String regex="^[A-Za-z\\s]{3,15}$";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(cname);
		if(m.matches()) {
			name=cname;
			return true;
		}
		else if(cname==null)
		{
			System.out.println("name is empty please give a one name ");
			return name();
		}
		else
		{
			System.out.println("sry name should minimum three character or only characters...... ");
			return name();
		}
		
	}
	public boolean email() {
	System.out.println("Enter your Email : ");
	String cemail=s.next();
	String regex="^[a-zA-Z]{1}[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]{5}[.]{1}[a-zA-Z]+$";
	Pattern p=Pattern.compile(regex);
	Matcher m=p.matcher(cemail);
	if(m.matches()) {
		email=cemail;
		return true;
	}
	else if(cemail==null)
	{
		System.out.println("email is empty please give a email ");
		return email();
	}
	else
	{
		System.out.println("Email Formate are wrong please give a correct email id ...... ");
		return email();
	}
		
	}
public boolean phnum() {
	System.out.println("Enter your phone num : ");
	String cphnum=s.next();
	String regex="^[7-9]{1}[0-9]{5,10}$";
	Pattern p=Pattern.compile(regex);
	Matcher m=p.matcher(cphnum);
	if(m.matches()) {
		phonenum=cphnum;
		return true;
	}
	else if(cphnum==null)
	{
		System.out.println("phonenum is empty please give a phone number ");
		return phnum();
	}
	else
	{
		System.out.println("Phone number should only numbers or Phone num format or Wrong ...... ");
		return phnum();
	}
	
}





	public void login() 
	{
		id();
		//System.out.println("Enter your password :");
		 //password=s.nextLine();
	
		
		
	}
	public void Clogin() {
		name();
		
		//System.out.println("Enter your password :");
		 //password=s.nextLine();
		
	}
	
	public boolean fromlocation() {
		System.out.println("Enter your from loacation : ");
		String cfromlocation=s.nextLine();
		String regex="^[A-Za-z]\\w{2,20}$";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(cfromlocation);
		if(m.matches()) {
			fromlocation=cfromlocation;
			return true;
		}
		else if(cfromlocation==null)
		{
			System.out.println("fromlocation is empty please give a one name ");
			return fromlocation();
		}
		else
		{
			System.out.println("sry fromlocation should only characters...... ");
			return fromlocation();
		}
		
	}
	public boolean Tolocation() {
		System.out.println("Enter your Destination : ");
		String cTolocation=s.nextLine();
		String regex="^[A-Za-z]\\w{2,20}$";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(cTolocation);
		if(m.matches()) {
			Tolocation=cTolocation;
			return true;
		}
		else if(cTolocation==null)
		{
			System.out.println("Tolocation is empty please give a one name ");
			return Tolocation();
		}
		else
		{
			System.out.println("sry Destination should only characters...... ");
			return Tolocation();
		}
		
	}
	public boolean Cdate() throws ParseException {
		System.out.println("Enter your journey date yyyy-MM-dd: ");
		String inputdate=s.next();
		SimpleDateFormat simple=new SimpleDateFormat("yyyy-MM-dd");
		String ldate=new SimpleDateFormat("yyyy-MM-dd").format(Calendar.getInstance().getTime());
		 
        
		 usefromdate=simple.parse(inputdate);
			locdate=simple.parse(ldate);
		
			
		if(!locdate.after(usefromdate)) {
			fromdate=usefromdate;
		
	
			return true;
		}
		else if(inputdate==null)
		{
			System.out.println("Date is empty please give a one date ....");
			return Cdate();
		}
		else
			
		{
			System.out.println("oops! you enter already passed date.... ");
			return Cdate();
		}
	}

		
	

		
	
	public void no() {
		System.out.println("choose your flexible bus no");
		bus_no=i.nextInt();
		//System.out.println(bus_no);
		
	}
	public void noforview() {
		System.out.println("Enter your booked busno : ");
		bus_no=i.nextInt();
		
	}


}
