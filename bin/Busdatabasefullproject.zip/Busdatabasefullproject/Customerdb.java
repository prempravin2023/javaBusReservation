package Busdatabasefullproject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Customerdb extends Connection {
	Scanner s=new Scanner(System.in);

	public void insert(Validation validate) throws SQLException {
String q="insert into customer values(?,?,?,?)";
		java.sql.PreparedStatement pst=con.prepareStatement(q);
		pst.setString(1,validate.name);
		pst.setString(2,validate.phonenum);
		pst.setString(3,validate.email);
		pst.setString(4,validate.password);
		int r=pst.executeUpdate();
		System.out.println("Register.....");
		}

	public boolean logincheck(Validation validate) throws SQLException {
		String q="select count(name) from customer where name=?";
		java.sql.PreparedStatement pst=con.prepareStatement(q);
		pst.setString(1,validate.name);
		ResultSet r=pst.executeQuery();
		r.next();
		if(r.getInt(1)>0)
		{
			return true;
		}
		else
		{
			System.out.println("Name is wrong.....");
			
			System.out.println("Enter your Name :");
			validate.name=s.next();
			return logincheck(validate);
		}

		
	}
	public boolean logincheck2() throws SQLException {
		String q="select count(name) from customer where password=?";
		java.sql.PreparedStatement pst=con.prepareStatement(q);
		System.out.println("Enter Your Password : ");
		String pass=s.next();
		pst.setString(1,pass);
		ResultSet r=pst.executeQuery();
		r.next();
		if(r.getInt(1)>0)
		{
			return true;
		}
		else
		{
			System.out.println("Password is wrong try again.....");

			return logincheck2();
		}
}
		
	}


