package Busdatabasefullproject;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.mysql.jdbc.PreparedStatement;

public class Admindb extends Connection {
       Scanner s=new Scanner(System.in);
	public void Add(Validation validate) throws SQLException {
		
		
		String q="insert into AdminReg values(?,?,?,?,?)";
		
		java.sql.PreparedStatement pst=con.prepareStatement(q);
		
		pst.setString(1,validate.Aid);
		pst.setString(2,validate.name);
		pst.setString(3,validate.email);
		pst.setString(4,validate.phonenum);
		pst.setString(5,validate.password);
		
		int r=pst.executeUpdate();
		System.out.println("Register.....");
		}

	

	public boolean logincheck(Validation validate) throws SQLException 
	 {
		
		String q="select count(name) from AdminReg where Aid=? ";
		java.sql.PreparedStatement pst=con.prepareStatement(q);
		
		pst.setString(1,validate.Aid);
		
		
		ResultSet r=pst.executeQuery();
		
	    r.next();
	    if( r.getInt(1)>0)
	    {
	     return true;
	    }
	    else
	    {
	    	System.out.println("your id is Wrong....");
	    	System.out.println("Enter your id :");
	    	validate.Aid=s.next();
	    	
	    	return logincheck(validate);
	    }
	 }



	public boolean logincheck2() throws SQLException {
		String q="select count(name) from AdminReg where password=? ";
		java.sql.PreparedStatement pst=con.prepareStatement(q);
		System.out.println("Enter your password : ");
	    String password=s.next();
		pst.setString(1,password);
		
		
		ResultSet r=pst.executeQuery();
		
	    r.next();
	    if( r.getInt(1)>0)
	    {
	    	return true;
	    }
	    else
	    {
	    	System.out.println("your password is Wrong try again....");
	    	return logincheck2();
	    }
		
	}
}