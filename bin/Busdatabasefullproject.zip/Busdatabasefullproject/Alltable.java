package Busdatabasefullproject;


import java.sql.SQLException;
import java.util.Scanner;



public class Alltable {
	Scanner i=new Scanner(System.in);
	Scanner s=new Scanner(System.in);
	
	public void tables() throws SQLException 
	{
	
	System.out.println("Enter 1  || For Bus Table");
	System.out.println("Enter 2  || For Bookings Table");
	System.out.println("Enter 3  || Log out");
	
	    int option=i.nextInt();
	
		if(option==1)
		{
			Bus bus=new Bus();
			bus.busdetailes();
		}
		else if(option==2)
		{
			Bookingdata booking=new Bookingdata();
			booking.bookingdetailes();
		}
		else if(option==3)
		{
			System.out.println("Thankyou....");
		}
	
	}

	public void Customertables() {
		int option=1;
		try {
		while(option==1 || option==2 || option==3)
		{
			
			System.out.println("Enter 1  || For Bus Ticket Booking");
			System.out.println("Enter 2  || For Bus Ticket Cancel");
			System.out.println("Enter 3  || For View the Ticket");
			System.out.println("Enter 4  || For Logout");
			
			option=i.nextInt();
			if(option==1) {
			
			Bookingdata booking=new Bookingdata();
			Validation validate=new Validation();
			validate.fromlocation();
			validate.Tolocation();
			if(booking.state(validate)) 
			{
				
				validate.name();
				validate.Cdate();
				validate.phnum();
				validate.email();
				Busdb busdb=new Busdb();
				busdb.Ddetailes();
		
				validate.no();
			
				if(booking.isAvailable(validate))
				{
					Bookingdb bookingdb=new Bookingdb();
		            bookingdb.book(validate);
					System.out.println("your ticket was booking : ");
				}
				else
				{
					System.out.println("Sry bus was full try another bus");
				}
			}
			else 
			{
				System.out.println("sry this route is not avialable......");
			}
			}
			else if(option==2) {
	
				Validation validate=new Validation();
				validate.noforview();
				validate.name();
				validate.phnum();
				validate.Cdate();
				Bookingdb bookingdb=new Bookingdb();
				
				if(bookingdb.isCancelled(validate)) 
				{
					System.out.println("your ticket was cancelled : ");
				}
				else 
				{
					System.out.println("Please give a Correct Passnger Information : ");
				}
				
			
				
			}
			else if(option==3) {
				Validation validate=new Validation();
				
				Bookingdb bookingdb=new Bookingdb();
				
				validate.noforview();
				validate.name();
				validate.phnum();
				validate.Cdate();
				
				
				
				if(bookingdb.view(validate)) 
				{
					
				}
				else
				{
					System.out.println("Please give a Correct Passnger Information : ");
				}
			}
			else
			{
				System.out.println("Thank you......");
			}
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}

}
