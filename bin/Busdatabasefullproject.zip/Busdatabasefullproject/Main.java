package Busdatabasefullproject;

import java.sql.SQLException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws SQLException {
		Scanner i=new Scanner(System.in);
		Scanner s=new Scanner(System.in);
		Connection dbcon=new Connection();
		
		System.out.println("Select 1 for || Admin Registration ");
		System.out.println("Select 2 for || Admin Login ");
		System.out.println("Select 3 for || Customer  Registration ");
		System.out.println("Select 4 for || Customer Login ");
		int option=i.nextInt();
		if(option==1) 
		 {
			Validation validate=new Validation();
			validate.id();
			validate.Register();
			Admindb admindb=new Admindb();
			admindb.Add(validate);
			System.out.println("Enter 1 Go to login :");
			int login=i.nextInt();
			if(login==1)
			{

				Validation validate1=new Validation();
				validate1.id();
				Admindb admindb1=new Admindb();
				if(admindb1.logincheck(validate) &&admindb1.logincheck2() )
				{
					System.out.println("login Success....");
					Alltable alltable=new Alltable();
					alltable.tables();
					
				}
				else
				{
					System.out.println("Invalid Aid OR password ");
					System.out.println("Please Retry");
				}
			}
		}
		else if(option==2) 
		{
			Validation validate=new Validation();
			validate.id();
			Admindb admindb=new Admindb();
			if(admindb.logincheck(validate) &&admindb.logincheck2() )
			{
				System.out.println("login Success....");
				Alltable alltable=new Alltable();
				alltable.tables();
				
			}
			else
			{
				System.out.println("Invalid Adminid OR password ");
				System.out.println("Please Retry");
			}
		}
		else if(option==3)
		{
			Validation validate=new Validation();
	
			validate.Register();
			Customerdb customerdb=new Customerdb();
			customerdb.insert(validate);
			
			System.out.println("Enter 1 Go to login :");
			int login=i.nextInt();
			if(login==1)
			{
                
				Validation validate1=new Validation();
				validate1.name();
				Customerdb customerdb1=new Customerdb();
				if(customerdb1.logincheck(validate) && customerdb1.logincheck2() )
				{
					System.out.println("login Success....");
					Alltable alltable=new Alltable();
					alltable.Customertables();
				}
			}
		}
		else if(option==4)
		{
			Validation validate=new Validation();
			validate.name();
			Customerdb customerdb=new Customerdb();
			if(customerdb.logincheck(validate) && customerdb.logincheck2() )
			{
				System.out.println("login Success....");
				Alltable alltable=new Alltable();
				alltable.Customertables();
			}
		}

	}

}
