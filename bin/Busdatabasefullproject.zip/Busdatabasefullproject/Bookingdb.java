package Busdatabasefullproject;


import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;



public class Bookingdb extends Connection {

	Scanner i=new Scanner(System.in);
	Scanner s=new Scanner(System.in);
	
	public void Showpassangeralist() throws SQLException {
		String q="select * from bookings";
		PreparedStatement pst=con.prepareStatement(q);
		
		ResultSet r=pst.executeQuery();
		
			while(r.next()) {
				
			    String dname=r.getString(1);
			    String dfrompoint=r.getString(2);
			    String ddetination=r.getString(3);
			    Date dFdate=r.getDate(4);
			    String dEmail=r.getString(5);
			    long dpnum=r.getLong(6);
			    int dbusNo=r.getInt(7);
			   System.out.println("Passanger detailes....");
			   System.out.println();
			   System.out.println("Passanger name                    : "+dname);
			   System.out.println("Passanger pickup-point            : "+dfrompoint);
			   System.out.println("Passanger destination             : "+ddetination);
			   System.out.println("date                              : "+dFdate);
			   System.out.println("Passanger Email                   : "+dEmail);
			   System.out.println("Passanger phone num               : "+dEmail);
			   System.out.println("Booking busno                     : "+dbusNo);
			   
			  }
			   System.out.println("Enter 1 For || Go to back");
			   int option=i.nextInt();
			   if(option==1)
		          {
			Alltable alltable=new Alltable();
			alltable.tables();
		       	  }
	}

	public int getCount(int bus_no, Date fromdate) throws SQLException {
		
		 
		 String q="select count(Pname) from bookings where busNo=? and Fdate=?";
				
				 java.sql.PreparedStatement pst=con.prepareStatement(q);
				 
				 pst.setInt(1,bus_no);
				 
				 java.sql.Date sqldate=new java.sql.Date(fromdate.getTime());
				 pst.setDate(2,sqldate);
				
				 ResultSet  r=pst.executeQuery();
				
				 r.next();
				
				 return  r.getInt(1);
			}
			


		public void book(Validation validate) throws SQLException {
		
			String q="insert into bookings values(?,?,?,?,?,?,?)";
			PreparedStatement pst=con.prepareStatement(q);
			pst.setString(1,validate.name);
			pst.setString(2,validate.fromlocation);
			pst.setString(3,validate.Tolocation);
			
			java.sql.Date sqldate=new java.sql.Date(validate.fromdate.getTime());
			
			pst.setDate(4,sqldate);
			
			pst.setString(5,validate.email);
			pst.setString(6,validate.phonenum);
			pst.setInt(7,validate.bus_no);
			int r=pst.executeUpdate();
			
			
		}



		public boolean isCancelled(Validation validate) throws SQLException {
		String q="delete from bookings where busNo =? and Fdate=? and Pnum=?";
			
			PreparedStatement pst=con.prepareStatement(q);
			
			pst.setInt(1,validate.bus_no);
			java.sql.Date sqldate=new java.sql.Date(validate.fromdate.getTime());
			pst.setDate(2,sqldate);
			
			pst.setString(3,validate.phonenum);
			int r=pst.executeUpdate();
			return r>0;
			
		}


		
		public boolean view(Validation validate) throws SQLException {
			
			String q="select Pname,frompoint,detination,Fdate,busname,bustype,Drivernum,Time from bookings inner join buses where"
					+ " bookings.busNo=? and bookings.Pnum=? and bookings.Fdate=? and buses.busno=? ";
			PreparedStatement pst=con.prepareStatement(q);
			pst.setInt(1,validate.bus_no);
			
			pst.setString(2,validate.phonenum);
			
			java.sql.Date sqldate=new java.sql.Date(validate.fromdate.getTime());
			pst.setDate(3,sqldate);
			pst.setInt(4,validate.bus_no);
			
			
			ResultSet r=pst.executeQuery();
		    int a=0;
				while(r.next()) {
					
				    String dname=r.getString(1);
				    String dfrompoint=r.getString(2);
				    String ddetination=r.getString(3);
				    Date Fdate=r.getDate(4);
				    String dbusname=r.getString(5);
				    String dbustype=r.getString(6);
				    long Mnum=r.getLong(7);
				    String dtime=r.getString(8);
				    
				    
				    System.out.println("Booking detailes");
				    System.out.println();
				    
				   System.out.println("Passanger name       : "+dname);
				   System.out.println("Bus name             : "+dbusname);
				   System.out.println("From                 : "+dfrompoint);
				   System.out.println("To                   : "+ddetination);
				   System.out.println("date                 : "+Fdate);
				   System.out.println("Time                 : "+dtime);
				   System.out.println("Bustype              : "+dbustype);
				   System.out.println("DriverMobilenum      : "+Mnum);
				   System.out.println("........................................");
				   a=1;
				   
				  }
			if(a==1)
			{
			    return true;
			}
			else
			{
				return false;
				
			}
		}

	

}
