package Busdatabasefullproject;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;




public class Bookingdata {
	Scanner s=new Scanner(System.in);
	Scanner i=new Scanner(System.in);
	
	
	public void bookingdetailes() throws SQLException 
	{
		System.out.println("Enter 1 For || show the passenger list");
		System.out.println("Enter 2 For || Go to back");
		int option=i.nextInt();
		if(option==1)
		{
			Bookingdb bookingdb=new Bookingdb();
			bookingdb.Showpassangeralist();
		}
		else if(option==2)
		{
			Alltable alltable=new Alltable();
			alltable.tables();
		}
		
	}
	
	public boolean state(Validation validate) {

		
		int f=0,k;
		String floc[]= {"chennai","coimbatore","tirunelveli","tenkasi","bengalore","tirchy","madurai","salem"};
		String dloc[]= {"chennai","coimbatore","tirunelveli","tenkasi","bengalore","tirchy","madurai","salem"};
		if(!validate.fromlocation.equalsIgnoreCase(validate.Tolocation)) 
		{
		for( k=0;k<floc.length;k++) {
			if(validate.fromlocation.equalsIgnoreCase(floc[k]))
			{
			f++;
		    }
		if(validate.Tolocation.equalsIgnoreCase(floc[k])) 
		    {
		f++;
	       }
		}
		
	}
		else {
			
			return false;
		}
		return f==2;
	    
	
		}
public void getvalue() throws ParseException 
	{
		Validation validate=new Validation();


		validate.no();
		validate.name();
		validate.phnum();
		validate.Cdate();
		
		
	}

	public boolean isAvailable(Validation validate2) throws SQLException {
		int capacity=0;
		int booked=0;
		Busdb busdb=new Busdb();
		
		capacity=busdb.getCapacity(validate2.bus_no);
		
		Bookingdb bookingdb=new Bookingdb();
		booked=bookingdb.getCount(validate2.bus_no,validate2.fromdate);
		
	      
		return booked<capacity;
		
	}

	public void getvalue1() {
		Validation validate=new Validation();
		validate.no();
	}

	
}
