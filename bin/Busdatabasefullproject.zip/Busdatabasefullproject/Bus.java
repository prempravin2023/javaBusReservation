
package Busdatabasefullproject;

import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

public class Bus {
	Scanner i=new Scanner(System.in);
	Scanner s=new Scanner(System.in);
	int busid;
	int busno;
	int busno1;
	String busname;
	String Time;
	String bustype;
	long Drivernum;
	int capacity;
	
	public void busdetailes() throws SQLException {
		

		System.out.println("Select 1 For || Insert the new bus");
		System.out.println("Select 2 For || Update the bus");
		System.out.println("Select 3 For || Delete the bus");
		System.out.println("Select 4 For || show the bus");
		System.out.println("Select 5 For || Go to Back");
		
		int option=i.nextInt();
		
		if(option==1)
		{
			System.out.println("Enter the busno :");
			busno=i.nextInt();
			System.out.println("Enter the busname :");
			busname=s.nextLine();
			System.out.println("Enter the bus time :");
			Time=s.nextLine();
			System.out.println("Enter the bustype :");
			bustype=s.nextLine();
			System.out.println("Enter the DriverNum :");
			Drivernum=i.nextLong();
			System.out.println("Enter the bus Capacity :");
			capacity=i.nextInt();
			Busdb busdb=new Busdb();
			busdb.insert(busno,busname,Time,bustype,Drivernum,capacity);
			
		}
		else if(option==2)
		{
			System.out.println("Enter 1 For || Update the busno column ");
			System.out.println("Enter 2 For || Update the busname column ");
			System.out.println("Enter 3 For || Update the Time column ");
			System.out.println("Enter 4 For || Update the bustype column ");
			System.out.println("Enter 5 For || Update the Drivernum column ");
			System.out.println("Enter 6 For || Update the capacity column ");
			int optionU=i.nextInt();
			if(optionU==1)
			{
				System.out.println("Enter which Bus_no you want Edit :");
				busno=i.nextInt();
				System.out.println("Enter your updated detailes :");
				busno1=i.nextInt();
				Busdb busdb=new Busdb();
				busdb.update(busid,busno1);
				
			}
			else if(optionU==2)
			{
				System.out.println("Enter which Bus_no you want Edit :");
				busno=i.nextInt();
				System.out.println("Enter your updated detailes :");
				busname=s.nextLine();
				Busdb busdb=new Busdb();
				busdb.updatebusname(busno,busname);
				
			}
			else if(optionU==3)
			{
				System.out.println("Enter which Bus_no you want Edit :");
				busno=i.nextInt();
				System.out.println("Enter your updated detailes :");
				Time=s.nextLine();
				Busdb busdb=new Busdb();
				busdb.updatetime(busno,Time);
			}
			else if(optionU==4)
			{
				System.out.println("Enter which Bus_no you want Edit :");
				busno=i.nextInt();
				System.out.println("Enter your updated detailes :");
				bustype=s.nextLine();
				Busdb busdb=new Busdb();
				busdb.updatebustype(busno,bustype);
			}
			else if(optionU==5)
			{
				System.out.println("Enter which Bus_no you want Edit :");
				busno=i.nextInt();
				System.out.println("Enter your updated detailes :");
				Drivernum=s.nextLong();
				Busdb busdb=new Busdb();
				busdb.updateDrivernum(busno,Drivernum);
			}
			else if(optionU==6)
			{
				System.out.println("Enter which Bus_no you want Edit :");
				busno=i.nextInt();
				System.out.println("Enter your updated detailes :");
				capacity=s.nextInt();
				Busdb busdb=new Busdb();
				busdb.updatecapacity(busno,capacity);
			}
		}
		
		else if(option==3)
		{
			System.out.println("Enter which Bus_no you want Delete bus:");
			busno=i.nextInt();
			Busdb busdb=new Busdb();
			busdb.Delete(busno);	
		}
		else if(option==4)
		{
			System.out.println("Enter 1 For || show the All buses:");
			System.out.println("Enter 2 For || show the paritculer bus:");
			int optionS=i.nextInt();
			if(optionS==1)
			{
				
				Busdb busdb=new Busdb();
				busdb.Showbuses();	
			}
			else if(optionS==2)
			{
				Busdb busdb=new Busdb();
				System.out.println("Enter Bus_no to select the bus");
				busno=i.nextInt();
				busdb.Showparticulerbuses(busno);	
			}
		}
		else if(option==5)
		{
			Alltable alltable=new Alltable();
			alltable.tables();
		}
		
		
	}
	

}
