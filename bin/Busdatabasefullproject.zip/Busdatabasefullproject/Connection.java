package Busdatabasefullproject;

import java.sql.DriverManager;

public class Connection {
	
	java.sql.Connection con;
	Connection(){
		try 
		{
			
			String url="jdbc:mysql://localhost:3306/bus";
			String uname="root";
					String upass="";
	      con= DriverManager.getConnection(url,uname,upass);
		}
		catch(Exception e) {
			
			System.out.println(e);
		}
	}

}
