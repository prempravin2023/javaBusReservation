package Busdatabasefullproject;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Scanner;

public class Busdb extends Connection {
	Scanner i=new Scanner(System.in);
	Scanner s=new Scanner(System.in);

	public void insert(int busno, String busname, String time, String bustype, long drivernum, int capacity) throws SQLException {
		
		
		String q="insert into buses(busno,busname,Time,bustype,Drivernum,capacity)values(?,?,?,?,?,?)";
		PreparedStatement pst=con.prepareStatement(q);
		pst.setInt(1,busno);
		pst.setString(2,busname);
		pst.setString(3,time);
		pst.setString(4,bustype);
		pst.setLong(5,drivernum);
		pst.setInt(6,capacity);
		int r=pst.executeUpdate();
		System.out.println("Added.....");
		System.out.println("Enter 1 For || go to Back");
		int option=i.nextInt();
		if(option==1)
		{
		Bus bus=new Bus();
		bus.busdetailes();		}
		
		
	}



	public void update(int bus_no, int busno) throws SQLException {
		
		 String q="update buses set busno=? where busno=?";
      	 java.sql.PreparedStatement pst=con.prepareStatement(q);
     	   pst.setInt(1,busno);
     	  pst.setInt(2,bus_no);
     	  int r=pst.executeUpdate();
    	  
     	  if(r>0)
		{
    		 System.out.println("Updated.......");
		}
    	 else
    	 {
    		 System.out.println("Invalid detailes.....");
    	 }
    	 System.out.println("Enter 1 For || go to Back");
 		int option=i.nextInt();
 		if(option==1)
 		{
 		Bus bus=new Bus();
 		bus.busdetailes();
 		}
    	 
		 
	}



	public void updatebusname(int busno, String busname) throws SQLException {
		 String q="update buses set busname=? where busno=?";
      	 java.sql.PreparedStatement pst=con.prepareStatement(q);
    	  pst.setString(1,busname);
    	  pst.setInt(2,busno);
    	  int r=pst.executeUpdate();
    	  
    	 if(r>0)
		{
    		 System.out.println("Updated.......");
		}
    	 else
    	 {
    		 System.out.println("Invalid detailes.....");
    	 }
    	 System.out.println("Enter 1 For || go to Back");
 		int option=i.nextInt();
 		if(option==1)
 		{
 		Bus bus=new Bus();
 		bus.busdetailes();
 		}
 		
   }
public void updatetime(int busno, String time) throws SQLException {
		
	 String q="update buses set Time=? where busno=?";
  	 java.sql.PreparedStatement pst=con.prepareStatement(q);
	  pst.setString(1,time);
	  pst.setInt(2,busno);
	  int r=pst.executeUpdate();
	  
	 if(r>0)
	{
		 System.out.println("Updated.......");
	}
	 else
	 {
		 System.out.println("Invalid detailes.....");
	 }
	 System.out.println("Enter 1 For || go to Back");
		int option=i.nextInt();
		if(option==1)
		{
		Bus bus=new Bus();
		bus.busdetailes();
		}
		
	}



public void updatebustype(int busno, String bustype) throws SQLException {
	 String q="update buses set bustype=? where busno=?";
  	 java.sql.PreparedStatement pst=con.prepareStatement(q);
	  pst.setString(1,bustype);
	  pst.setInt(2,busno);
	  int r=pst.executeUpdate();
	  
	 if(r>0)
	{
		 System.out.println("Updated.......");
	}
	 else
	 {
		 System.out.println("Invalid detailes.....");
	 }
	 System.out.println("Enter 1 For || go to Back");
		int option=i.nextInt();
		if(option==1)
		{
		Bus bus=new Bus();
		bus.busdetailes();
		}
	}

public void updateDrivernum(int busno, long drivernum) throws SQLException {
	 String q="update buses set Drivernum=? where busno=?";
  	 java.sql.PreparedStatement pst=con.prepareStatement(q);
	  pst.setLong(1,drivernum);
	  pst.setInt(2,busno);
	  int r=pst.executeUpdate();
	  
	 if(r>0)
	{
		 System.out.println("Updated.......");
	}
	 else
	 {
		 System.out.println("Invalid detailes.....");
	 }
	 System.out.println("Enter 1 For || go to Back");
		int option=i.nextInt();
		if(option==1)
		{
		Bus bus=new Bus();
		bus.busdetailes();
		}
	
}



public void updatecapacity(int busno, int capacity) throws SQLException {
	String q="update buses set capacity=? where busno=?";
 	 java.sql.PreparedStatement pst=con.prepareStatement(q);
	  pst.setInt(1,capacity);
	  pst.setInt(2,busno);
	  int r=pst.executeUpdate();
	  
	 if(r>0)
	{
		 System.out.println("Updated.......");
	}
	 else
	 {
		 System.out.println("Invalid detailes.....");
	 }
	 System.out.println("Enter 1 For || go to Back");
		int option=i.nextInt();
		if(option==1)
		{
		Bus bus=new Bus();
		bus.busdetailes();
		}
	
}



public void Delete(int busno) throws SQLException {
String q="delete from buses where busno =?";
	
	PreparedStatement pst=con.prepareStatement(q);
	
	pst.setInt(1,busno);
	int r=pst.executeUpdate();
	if(r>0)
	{
	System.out.println("Deleted.....");	
	}
	else
	{
		System.out.println("Invalid detailes.....");	
	}
	 System.out.println("Enter 1 For || go to Back");
		int option=i.nextInt();
		if(option==1)
		{
		Bus bus=new Bus();
		bus.busdetailes();
		}
	
	
}



public void Showbuses() throws SQLException {
	String q="select * from buses";
	PreparedStatement pst=con.prepareStatement(q);
	
	ResultSet r=pst.executeQuery();
	
		while(r.next()) {
			
		    int dbusid=r.getInt(1);
		    int  dbusno=r.getInt(2);
		    String dbusname=r.getString(3);
		    String dtime=r.getString(4);
		    String dbustype=r.getString(5);
		    long ddrivernum=r.getLong(6);
		    int dcapacity=r.getInt(7);
		   System.out.println("Passanger detailes....");
		   
		   System.out.println("busid                : "+dbusid);
		   System.out.println("busno                : "+dbusno);
		   System.out.println("busname              : "+dbusname);
		   System.out.println("Time                 : "+dtime);
		   System.out.println("bustype              : "+dbustype);
		   System.out.println("Drivernum            : "+ddrivernum);
		   System.out.println("capacity             : "+dcapacity);
		   
		  }
		   System.out.println("Enter 1 For || Go to back");
		   int option=i.nextInt();
		   if(option==1)
	          {
			    Bus bus=new Bus();
				bus.busdetailes();
	       	  }
	
}







public void Showparticulerbuses(int busno) throws SQLException {
	
	String q="select * from buses where  busno=?";
	PreparedStatement pst=con.prepareStatement(q);
	pst.setInt(1, busno);
	ResultSet r=pst.executeQuery();
	
		while(r.next()) {
			
		    int dbusid=r.getInt(1);
		    int  dbusno=r.getInt(2);
		    String dbusname=r.getString(3);
		    String dtime=r.getString(4);
		    String dbustype=r.getString(5);
		    long ddrivernum=r.getLong(6);
		    int dcapacity=r.getInt(7);
		   System.out.println("Passanger detailes....");
		   
		   System.out.println("busid                : "+dbusid);
		   System.out.println("busno                : "+dbusno);
		   System.out.println("busname              : "+dbusname);
		   System.out.println("Time                 : "+dtime);
		   System.out.println("bustype              : "+dbustype);
		   System.out.println("Drivernum            : "+ddrivernum);
		   System.out.println("capacity             : "+dcapacity);
		   
		  }
		   System.out.println("Enter 1 For || Go to back");
		   int option=i.nextInt();
		   if(option==1)
	          {
			    Bus bus=new Bus();
				bus.busdetailes();
	       	  }
}

public void Ddetailes() throws SQLException{
	/*busid | busno | busname | Time | bustype | Drivernum  | capacity*/
    String q="select busid,busno,busname,Time,bustype,Drivernum from buses";
	java.sql.PreparedStatement pst= con.prepareStatement(q);
	ResultSet r=pst.executeQuery();
	while(r.next()) {
	int	busid=r.getInt(1);
	int busno=r.getInt(2);
	String	busname=r.getString(3);
	String time=r.getString(4);
	String	bustype=r.getString(5);
	long	Mnum = r.getLong(6);
	    System.out.println("Bus Id     :"+busid);
		System.out.println("Bus no     :"+busno);
		System.out.println("Bus Name   : "+busname);
		System.out.println("Bus time   : "+time);
		System.out.println("Bus Type   : "+bustype);
		System.out.println("Mobile Num : "+Mnum);
		System.out.println("...........................................");
		
	}
}

	public int getCapacity(int bus_no) throws SQLException 
	{
		
		String q="select capacity from buses where busno=?";
		//java.sql.SQLException: Illegal operation on empty result set.
		PreparedStatement pst=con.prepareStatement(q);
		
		pst.setInt(1,bus_no);
		ResultSet r=pst.executeQuery();
		
		r.next();
		return r.getInt(1);
		
		
	
	}

}


	


