package busdatabaseoriginal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;

import busdatabase.Displaydetailes;
import busdatabase.Insertdetailes;

public class Bookingdb extends Connection{

	public int getCount(int bus_no, Date odate) throws SQLException {
 String q="select count(pname) from bookings where busno=? and Fdate=?";
		 
		 java.sql.PreparedStatement pst=con.prepareStatement(q);
		 pst.setInt(1,bus_no);
		 
		 java.sql.Date sqldate=new java.sql.Date(odate.getTime());
		 pst.setDate(2,sqldate);
		 
		 ResultSet  r=pst.executeQuery();
		 r.next();
		 return  r.getInt(1);
	}
	


public void book(Bookingdata booking) throws SQLException {
	String q="insert into bookings values(?,?,?,?,?,?,?)";
	PreparedStatement pst=con.prepareStatement(q);
	pst.setString(1,booking.name);
	pst.setString(2,booking.pickup);
	pst.setString(3,booking.destination);
	java.sql.Date sqldate=new java.sql.Date(booking.odate.getTime());
	pst.setDate(4,sqldate);
	pst.setString(5,booking.mailid);
	pst.setLong(6,booking.num);
	pst.setInt(7,booking.bus_no);
	int r=pst.executeUpdate();
	
}



public boolean isCancelled(Bookingdata booking) throws SQLException {
String q="delete from bookings where busNo =? and Fdate=? and Pnum=?";
	
	PreparedStatement pst=con.prepareStatement(q);
	
	pst.setInt(1,booking.bus_no);
	java.sql.Date sqldate=new java.sql.Date(booking.odate.getTime());
	pst.setDate(2,sqldate);
	
	pst.setLong(3,booking.num);
	int r=pst.executeUpdate();
	return r>0;
	
}


// Pname | frompoint   | destination | Fdate      | Email          | Pnum       | busNo
//| busno | busname | bustype        | Mnum      | capacity 
public void view(Bookingdata booking) throws SQLException {
	
	String q="select Pname,frompoint,detination,Fdate,busname,bustype,Mnum from bookings inner join buses where"
			+ " bookings.busNo=? and Pnum=? and buses.busno=? ";
	PreparedStatement pst=con.prepareStatement(q);
	pst.setInt(1,booking.bus_no);
	pst.setLong(2,booking.num);
	pst.setInt(3,booking.bus_no);
	ResultSet r=pst.executeQuery();
	
	
	while(r.next()) {
	    String dname=r.getString(1);
	    String dfrompoint=r.getString(2);
	    String ddetination=r.getString(3);
	    Date Fdate=r.getDate(4);
	    String dbusname=r.getString(5);
	    String dbustype=r.getString(6);
	    long Mnum=r.getLong(7);
	    System.out.println("Booking detailes");
	    
	   System.out.println("Passanger name : "+dname);
	   System.out.println("Bus name       : "+dbusname);
	   System.out.println("From           : "+dfrompoint);
	   System.out.println("To             : "+ddetination);
	   System.out.println("date           : "+Fdate);
	   System.out.println("Bustype        : "+dbustype);
	   System.out.println("Mobilenum      : "+Mnum);
	   
	    
	   
	    
	}
	

	


}

}
