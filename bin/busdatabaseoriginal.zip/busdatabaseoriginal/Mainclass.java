package busdatabaseoriginal;

import java.sql.SQLException;
import java.util.Scanner;

import busdatabase.BUS;
import busdatabase.Displaydetailes;
import busdatabase.Insertdetailes;

public class Mainclass {

	public static void main(String[] args) throws SQLException {

		Scanner s=new Scanner(System.in);
		Scanner i=new Scanner(System.in);
		Connection bs=new Connection();
		int option=1;
		
		while(option==1 || option==2 || option==3) {
			
			System.out.println("Enter 1 to booking || 2 to Cancel ||  3 to view Ticket || 4 to exit");
			
			option=i.nextInt();
			if(option==1) {
			
			Bookingdata booking=new Bookingdata();
			
			if(booking.state()) 
			{
				booking.detailes();
				Busdb busdb=new Busdb();
				busdb.Ddetailes();
				booking.selectbusno();
				
				if(booking.isAvailable(booking))
				{
					Bookingdb bookingdb=new Bookingdb();
					bookingdb.book(booking);
					System.out.println("your ticket was booking : ");
				}
				else
				{
					System.out.println("Sry bus was full try another bus");
				}
			}
			else {
				System.out.println("sry this route is not avialable......");
			}
			}
			else if(option==2) {
				
				Bookingdata booking=new Bookingdata();
				booking.getvalue();
				Bookingdb bookingdb=new Bookingdb();
				if(bookingdb.isCancelled(booking)) 
				{
					System.out.println("your ticket was cancelled : ");
				}
				else 
				{
					System.out.println("Please give a Correct Passnger Information : ");
				}
				
//| athi  | tirunelveli | chennai    | 2023-01-01 | prem@mail.com | 9025872430 |     1				
				
			}
			else if(option==3) {
				Bookingdata booking=new Bookingdata();
				booking.getvalue();
				Bookingdb bookingdb=new Bookingdb();
				bookingdb.view(booking);
			}
		}


	}

}
