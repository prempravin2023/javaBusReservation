package busdatabaseoriginal;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Busdb extends Connection{
	
	int busno;
	String busname;
	String bustype;
    long Mnum;
	int capacity;
	
  public void Ddetailes() throws SQLException{
		    String q="select * from buses";
			java.sql.PreparedStatement pst= con.prepareStatement(q);
			ResultSet r=pst.executeQuery();
			while(r.next()) {
				busno=r.getInt(1);
				busname=r.getString(2);
				bustype=r.getString(3);
				Mnum = r.getLong(4);
				capacity=r.getInt(5);
				System.out.println("Bus no     :"+busno);
				System.out.println("Bus Name   : "+busname);
				System.out.println("Bus Type   : "+bustype);
				System.out.println("Mobile Num : "+Mnum);
				System.out.println("Bus capacity :"+capacity);
				System.out.println("...........................................");
				
			}
		}

public int getCapacity(int bus_no) throws SQLException {
	 String q="select capacity from buses where busno=?";
	 
	 PreparedStatement pst=con.prepareStatement(q);
	 pst.setInt(1,bus_no);
	 ResultSet  r=pst.executeQuery();
	 r.next();
	 return r.getInt(1);
	
}
		

 

	

}
