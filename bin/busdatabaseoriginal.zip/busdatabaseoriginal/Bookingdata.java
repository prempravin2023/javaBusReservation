package busdatabaseoriginal;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Bookingdata {
	
	Scanner s=new Scanner(System.in);
	Scanner i=new Scanner(System.in);
	String name;
	String pickup;
	int bus_no;
	String destination;
	Date odate;
	String mailid;
	long num;
	public boolean state() {
		System.out.println("Enter your from location : ");
		 pickup=s.nextLine();
		System.out.println("Enter your destination : ");
		destination=s.nextLine();
		int f=0,t=0,k;
		String floc[]= {"chennai","coimbatore","tirunelveli","tenkasi","bengalore","tirchy","madurai","salem"};
		String dloc[]= {"chennai","coimbatore","tirunelveli","tenkasi","bengalore","tirchy","madurai","salem"};
		
		for( k=0;k<floc.length;k++) {
			if(pickup.equalsIgnoreCase(floc[k]))
			{
			f++;
		    }
		if(destination.equalsIgnoreCase(floc[k])) 
		    {
		t++;
	       }
		
		
	}
		return f==t;
	    
	
		}
	public void detailes(){
		System.out.println("Enter your name : ");
		 name=s.nextLine();
		
		System.out.println("Enter your journey date DD-MM-YYYY: ");
		String inputdate=s.next();
		SimpleDateFormat simple=new SimpleDateFormat("dd-MM-yyyy");
        try {
			odate=simple.parse(inputdate);
		} catch (ParseException e) {
			
			e.printStackTrace();
			System.out.println(e);
		}
		
		System.out.println("Enter your phone num  : ");
		 num=s.nextLong();
		 System.out.println("Enter your Email  : ");
			mailid=s.next();
}
	public void selectbusno() {
		System.out.println("Choose your flexible busno and press the enter.... ");
		bus_no=i.nextInt();
	}
	public boolean isAvailable(Bookingdata booking) throws SQLException {
		int capacity=0;
		int booked=0;
		Busdb busdb=new Busdb();
		capacity=busdb.getCapacity(bus_no);
		Bookingdb bookingdb=new Bookingdb();
		booked=bookingdb.getCount(bus_no,odate);
	      
		return booked<capacity;
	
		
	}
	public void getvalue() {
		System.out.println("Enter your booked busno");
		bus_no=i.nextInt();
		System.out.println("Enter your name :");
		name=s.nextLine();
		System.out.println("Enter your phone num : ");
		num=i.nextLong();
		
		System.out.println("Enter your booking date dd-mm-yyyy :");
		
		String rdate=s.next();
		SimpleDateFormat ordate=new SimpleDateFormat("dd-mm-yyyy");
		try {
			odate=ordate.parse(rdate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
	
	
	}
